package com.codeslap.sms.common;

/**
 * @author cristian
 * @version 1.0
 */
public class HttpConstants {
    public static final String GET_ALL_MESSAGES = "/get-all-messages";
    public static final String CLEAR_MESSAGES = "/clear-messages";
    public static final String SEND_MESSAGE = "/send-message";
    public static final String XML_EXTENSION = ".xml";
    public static final String CSS_EXTENSION = ".css";
    public static final String CSS_MIME_TYPE = "text/css";
    public static final String JPG_EXTENSION = ".jpg";
    public static final String PNG_MIME_TYPE = "image/png";
    public static final String PNG_EXTENSION = ".png";
    public static final String JPG_MIME_TYPE = "text/jpg";
    public static final String ICO_EXTENSION = ".ico";
    public static final String ICON_MIME_TYPE = "image/x-icon";
    public static final String XML_MIME_TYPE = "text/xml";
    public static final String PARAM_NUMBER = "number";
    public static final String PARAM_BODY = "body";
    public static final String PARAM_SINCE = "since";
    public static final String VALUE_TODAY = "today";
    public static final String VALUE_YESTERDAY = "yesterday";
    public static final String VALUE_THIS_WEEK = "this_week";
    public static final String VALUE_LAST_WEEK = "last_week";
}
