package com.codeslap.sms.common.bean;

import com.codeslap.sms.common.bean.SmsMessage;
import org.simpleframework.xml.*;

import java.util.List;

/**
 * @author cristian
 * @version 1.0
 */
@Root
@Default(value = DefaultType.FIELD, required = true)
public class Conversation {
    @Attribute(required = true)
    private long id;
    @ElementList(required = true, entry = "message", type = SmsMessage.class, inline = true)
    private List<SmsMessage> messages;

    public List<SmsMessage> getMessages() {
        return messages;
    }

    public void setMessages(List<SmsMessage> messages) {
        this.messages = messages;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Conversation that = (Conversation) o;

        if (id != that.id) return false;
        if (messages != null ? !messages.equals(that.messages) : that.messages != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) (id ^ (id >>> 32));
        result = 31 * result + (messages != null ? messages.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "\nConversation{" +
                "id=" + id +
                ", messages=" + messages +
                '}';
    }
}
