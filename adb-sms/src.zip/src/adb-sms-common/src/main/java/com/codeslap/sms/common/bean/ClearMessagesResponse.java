package com.codeslap.sms.common.bean;

import org.simpleframework.xml.Default;
import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.Root;

/**
 * @author cristian
 * @version 1.0
 */
@Root(name = "clear_messages")
@Default(DefaultType.FIELD)
public class ClearMessagesResponse extends BaseResponse {
    private int deleted;
    private long since;

    public int getDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }

    public void setSince(long since) {
        this.since = since;
    }

    public long getSince() {
        return since;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        ClearMessagesResponse that = (ClearMessagesResponse) o;

        if (deleted != that.deleted) return false;
        if (since != that.since) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + deleted;
        result = 31 * result + (int) (since ^ (since >>> 32));
        return result;
    }

    @Override
    public String toString() {
        return "ClearMessagesResponse{" +
                "deleted=" + deleted +
                ", since=" + since +
                '}';
    }
}
