package com.codeslap.sms.common.bean;

import org.simpleframework.xml.Default;
import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.Root;

/**
 * @author cristian
 * @version 1.0
 */
@Root
@Default(DefaultType.FIELD)
public class BaseResponse {
    private String device;
    private String brand;
    private String model;
    private String release;
    private int sdk;

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        this.device = device;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(String release) {
        this.release = release;
    }

    public int getSdk() {
        return sdk;
    }

    public void setSdk(int sdk) {
        this.sdk = sdk;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        BaseResponse that = (BaseResponse) o;

        if (sdk != that.sdk) return false;
        if (brand != null ? !brand.equals(that.brand) : that.brand != null) return false;
        if (device != null ? !device.equals(that.device) : that.device != null) return false;
        if (model != null ? !model.equals(that.model) : that.model != null) return false;
        if (release != null ? !release.equals(that.release) : that.release != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = device != null ? device.hashCode() : 0;
        result = 31 * result + (brand != null ? brand.hashCode() : 0);
        result = 31 * result + (model != null ? model.hashCode() : 0);
        result = 31 * result + (release != null ? release.hashCode() : 0);
        result = 31 * result + sdk;
        return result;
    }

    @Override
    public String toString() {
        return "BaseResponse{" +
                "device='" + device + '\'' +
                ", brand='" + brand + '\'' +
                ", model='" + model + '\'' +
                ", release='" + release + '\'' +
                ", sdk=" + sdk +
                '}';
    }
}
