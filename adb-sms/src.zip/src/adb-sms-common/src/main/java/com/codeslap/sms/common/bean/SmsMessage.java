package com.codeslap.sms.common.bean;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Default;
import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.Root;

/**
 * @author cristian
 * @version 1.0
 */
@Root
@Default(value = DefaultType.FIELD, required = false)
public class SmsMessage {
    @Attribute
    private long id;
    private long threadId;
    private String address;
    private String person;
    private long date;
    private long dateSent;
    private long protocol;
    private boolean read;
    private int status;
    private int type;
    private boolean replyPathPresent;
    private String subject;
    private String body;
    private String serviceCenter;
    private boolean locked;
    private int errorCode;
    private boolean seen;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getThreadId() {
        return threadId;
    }

    public void setThreadId(long threadId) {
        this.threadId = threadId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPerson() {
        return person;
    }

    public void setPerson(String person) {
        this.person = person;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public long getDateSent() {
        return dateSent;
    }

    public void setDateSent(long dateSent) {
        this.dateSent = dateSent;
    }

    public long getProtocol() {
        return protocol;
    }

    public void setProtocol(long protocol) {
        this.protocol = protocol;
    }

    public boolean isRead() {
        return read;
    }

    public void setRead(boolean read) {
        this.read = read;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getServiceCenter() {
        return serviceCenter;
    }

    public void setServiceCenter(String serviceCenter) {
        this.serviceCenter = serviceCenter;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public boolean isSeen() {
        return seen;
    }

    public void setSeen(boolean seen) {
        this.seen = seen;
    }

    public boolean isReplyPathPresent() {
        return replyPathPresent;
    }

    public void setReplyPathPresent(boolean replyPathPresent) {
        this.replyPathPresent = replyPathPresent;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SmsMessage that = (SmsMessage) o;

        if (date != that.date) return false;
        if (dateSent != that.dateSent) return false;
        if (errorCode != that.errorCode) return false;
        if (id != that.id) return false;
        if (locked != that.locked) return false;
        if (protocol != that.protocol) return false;
        if (read != that.read) return false;
        if (replyPathPresent != that.replyPathPresent) return false;
        if (seen != that.seen) return false;
        if (status != that.status) return false;
        if (threadId != that.threadId) return false;
        if (type != that.type) return false;
        if (address != null ? !address.equals(that.address) : that.address != null) return false;
        if (body != null ? !body.equals(that.body) : that.body != null) return false;
        if (person != null ? !person.equals(that.person) : that.person != null) return false;
        if (serviceCenter != null ? !serviceCenter.equals(that.serviceCenter) : that.serviceCenter != null)
            return false;
        if (subject != null ? !subject.equals(that.subject) : that.subject != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) (id ^ (id >>> 32));
        result = 31 * result + (int) (threadId ^ (threadId >>> 32));
        result = 31 * result + (address != null ? address.hashCode() : 0);
        result = 31 * result + (person != null ? person.hashCode() : 0);
        result = 31 * result + (int) (date ^ (date >>> 32));
        result = 31 * result + (int) (dateSent ^ (dateSent >>> 32));
        result = 31 * result + (int) (protocol ^ (protocol >>> 32));
        result = 31 * result + (read ? 1 : 0);
        result = 31 * result + status;
        result = 31 * result + type;
        result = 31 * result + (replyPathPresent ? 1 : 0);
        result = 31 * result + (subject != null ? subject.hashCode() : 0);
        result = 31 * result + (body != null ? body.hashCode() : 0);
        result = 31 * result + (serviceCenter != null ? serviceCenter.hashCode() : 0);
        result = 31 * result + (locked ? 1 : 0);
        result = 31 * result + errorCode;
        result = 31 * result + (seen ? 1 : 0);
        return result;
    }

    @Override
    public String toString() {
        return "\nSmsMessage{" +
                "id=" + id +
                ", threadId=" + threadId +
                ", address='" + address + '\'' +
                ", person='" + person + '\'' +
                ", date=" + date +
                ", dateSent=" + dateSent +
                ", protocol=" + protocol +
                ", read=" + read +
                ", status=" + status +
                ", type=" + type +
                ", replyPathPresent=" + replyPathPresent +
                ", subject='" + subject + '\'' +
                ", body='" + body + '\'' +
                ", serviceCenter='" + serviceCenter + '\'' +
                ", locked=" + locked +
                ", errorCode=" + errorCode +
                ", seen=" + seen +
                '}';
    }
}
