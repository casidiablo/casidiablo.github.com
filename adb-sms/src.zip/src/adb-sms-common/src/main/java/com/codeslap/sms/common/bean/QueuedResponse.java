package com.codeslap.sms.common.bean;

import org.simpleframework.xml.Default;
import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.Root;

/**
 * @author cristian
 * @version 1.0
 */
@Root(name = "queued_response")
@Default(DefaultType.FIELD)
public class QueuedResponse extends BaseResponse {
    private boolean queued;

    public boolean isQueued() {
        return queued;
    }

    public void setQueued(boolean queued) {
        this.queued = queued;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        QueuedResponse that = (QueuedResponse) o;

        return queued == that.queued;

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (queued ? 1 : 0);
        return result;
    }

    @Override
    public String toString() {
        return "QueuedResponse{" +
                "queued=" + queued +
                '}';
    }
}
