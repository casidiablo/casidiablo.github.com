package com.codeslap.sms.client.http;

import org.apache.http.HttpResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * // TODO write description
 *
 * @author robolectric team
 */
public class Response {
    private static final int BUFFER_SIZE = 4096;
    private int statusCode;
    private String responseBody;

    public Response(HttpResponse httpResponse) {
        statusCode = httpResponse.getStatusLine().getStatusCode();
        try {
            responseBody = fromStream(httpResponse.getEntity().getContent());
        } catch (IOException e) {
            throw new RuntimeException("error reading response body", e);
        }
    }

    public int getStatusCode() {
        return statusCode;
    }

    public String getResponseBody() {
        return responseBody;
    }

    public String fromStream(InputStream inputStream) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream), BUFFER_SIZE);
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        try {
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line).append("\n");
            }
        } finally {
            inputStream.close();
        }
        return stringBuilder.toString();
    }
}
