package com.codeslap.sms.client;

import com.codeslap.sms.common.bean.ClearMessagesResponse;
import com.codeslap.sms.common.bean.GetAllMessagesResponse;
import com.codeslap.sms.common.bean.QueuedResponse;

/**
 * @author cristian
 * @version 1.0
 */
public interface AdbSmsClient {
    GetAllMessagesResponse getAllMessages();

    ClearMessagesResponse clearMessages(String since);

    QueuedResponse sendMessage(String number, String body);
}
