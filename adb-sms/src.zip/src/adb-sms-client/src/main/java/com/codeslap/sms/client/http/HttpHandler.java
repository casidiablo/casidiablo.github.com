package com.codeslap.sms.client.http;

import org.apache.http.HttpEntity;
import org.apache.http.HttpVersion;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.VersionInfo;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HttpHandler {

    private static final int TIMEOUT = 15000;

    private static HttpParams createHttpParams(HttpParams params) {
        HttpConnectionParams.setConnectionTimeout(params, TIMEOUT);
        HttpConnectionParams.setSoTimeout(params, TIMEOUT);
        HttpProtocolParams.setVersion(params,
                HttpVersion.HTTP_1_1);
        HttpProtocolParams.setContentCharset(params,
                HTTP.DEFAULT_CONTENT_CHARSET);

        /*
        * Android note: Send each request body without first asking the server
        * whether it will be accepted. Asking first slows down the common case
        * and results in "417 expectation failed" errors when a HTTP/1.0 server
        * is behind a proxy. http://b/2471595
        */
        HttpProtocolParams.setUseExpectContinue(params, false); // android-changed

        // determine the release version from packaged version info
        final VersionInfo vi = VersionInfo.loadVersionInfo("org.apache.http.client", HttpHandler.class.getClassLoader());
        final String release = (vi != null) ? vi.getRelease() : VersionInfo.UNAVAILABLE;
        HttpProtocolParams.setUserAgent(params, "Apache-HttpClient/" + release + " (java 1.4)");
        return params;
    }

    private static HttpHandler instance;

    private HttpHandler() {
    }

    public static HttpHandler getInstance() {
        if (instance == null) {
            instance = new HttpHandler();
        }
        return instance;
    }

    public Response post(String url, Map<String, String> params)
            throws IOException, URISyntaxException {
        HttpPost post = new HttpPost(url);
        post.setEntity(mapToEntity(params));
        return makeRequest(post);
    }

    public Response get(String url) throws IOException, URISyntaxException {
        return makeRequest(new HttpGet(url));
    }

    private Response makeRequest(HttpUriRequest request) {
        DefaultHttpClient client = null;
        try {
            client = getPromiscuousDefaultClient();
            return new Response(client.execute(request));
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            if (client != null) {
                try {
                    client.getConnectionManager().shutdown();
                } catch (Exception ignored) {
                }
            }
        }
    }

    private DefaultHttpClient getPromiscuousDefaultClient() {
        HttpParams parameters = new BasicHttpParams();
        SchemeRegistry schemeRegistry = new SchemeRegistry();
        schemeRegistry.register(new Scheme("https", new CertificateIgnoringSSLSocketFactory(), 443));
        schemeRegistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
        ClientConnectionManager manager = new ThreadSafeClientConnManager(parameters, schemeRegistry);
        createHttpParams(parameters);
        return new DefaultHttpClient(manager, parameters);
    }

    /**
     * Convert a Map to UrlEncodedFormEntity
     *
     * @param parameters A Map of key:value
     * @return UrlEncodedFormEntity using UTF-8 encoding
     * @throws java.io.UnsupportedEncodingException
     *          if UTF-8 encoding is not supported
     */
    private static HttpEntity mapToEntity(Map<String, String> parameters)
            throws UnsupportedEncodingException {
        if (parameters == null) {
            parameters = new HashMap<String, String>();
        }

        if (parameters.isEmpty()) {
            return null;
        }

        // if there are no files to upload, return a simple UrlEncodedFormEntity
        ArrayList<NameValuePair> parametersList = new ArrayList<NameValuePair>();
        for (Map.Entry element : parameters.entrySet()) {
            NameValuePair nameValuePair = new BasicNameValuePair((String) element.getKey(), (String) element.getValue());
            parametersList.add(nameValuePair);
        }
        return new UrlEncodedFormEntity(parametersList, HTTP.UTF_8);
    }
}