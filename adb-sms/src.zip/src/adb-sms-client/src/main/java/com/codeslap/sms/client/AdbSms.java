package com.codeslap.sms.client;

import com.codeslap.sms.client.http.HttpHandler;
import com.codeslap.sms.client.http.Response;
import com.codeslap.sms.common.HttpConstants;
import com.codeslap.sms.common.bean.ClearMessagesResponse;
import com.codeslap.sms.common.bean.GetAllMessagesResponse;
import com.codeslap.sms.common.bean.QueuedResponse;
import com.codeslap.sms.common.xml.XmlHelper;

import java.util.HashMap;

/**
 * @author cristian
 * @version 1.0
 */
public class AdbSms implements AdbSmsClient {

    private final HttpHandler mHttpHandler;
    private final String mBaseUrl;

    public AdbSms(String baseUrl) {
        mBaseUrl = baseUrl;
        mHttpHandler = HttpHandler.getInstance();
    }

    @Override
    public GetAllMessagesResponse getAllMessages() {
        try {
            Response response = mHttpHandler.get(buildUrl(HttpConstants.GET_ALL_MESSAGES));
            return XmlHelper.fromXml(GetAllMessagesResponse.class, response.getResponseBody());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public ClearMessagesResponse clearMessages(String since) {
        String url = buildUrl(HttpConstants.CLEAR_MESSAGES);
        if (since != null) {
            url += "?" + HttpConstants.PARAM_SINCE + "=" + since;
        }
        try {
            Response response = mHttpHandler.get(url);
            return XmlHelper.fromXml(ClearMessagesResponse.class, response.getResponseBody());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public QueuedResponse sendMessage(String number, String body) {
        HashMap<String, String> parameters = new HashMap<String, String>();
        parameters.put(HttpConstants.PARAM_NUMBER, number);
        parameters.put(HttpConstants.PARAM_BODY, body);

        try {
            String url = buildUrl(HttpConstants.SEND_MESSAGE);
            Response response = mHttpHandler.post(url, parameters);
            return XmlHelper.fromXml(QueuedResponse.class, response.getResponseBody());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private String buildUrl(String method) {
        return mBaseUrl + method + HttpConstants.XML_EXTENSION;
    }
}
