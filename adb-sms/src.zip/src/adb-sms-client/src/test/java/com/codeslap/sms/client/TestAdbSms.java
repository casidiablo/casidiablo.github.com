package com.codeslap.sms.client;

import com.codeslap.sms.common.bean.*;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * @author cristian
 * @version 1.0
 */
public class TestAdbSms {

    private AdbSmsClient adbSms;

    @Before
    public void setup() {
        adbSms = new AdbSms("http://127.0.0.1:54546");
    }

    @Test
    public void testGetAllSms() {
        GetAllMessagesResponse allMessages = adbSms.getAllMessages();
        assertNotNull(allMessages);
        assertBaseResponse(allMessages);
        if (allMessages.getConversations() == null) {
            System.out.println("There are no conversations in the supplied url");
            return;
        }
        for (Conversation conversation : allMessages.getConversations()) {
            assertNotNull(conversation);
            long id = conversation.getId();
            assertNotNull(id);
            assertNotNull(conversation.getMessages());
            for (SmsMessage smsMessage : conversation.getMessages()) {
                assertNotNull(smsMessage);
                assertEquals(id, smsMessage.getThreadId());
                assertNotNull(smsMessage.getAddress());
                assertNotNull(smsMessage.getBody());
            }
        }
    }

    @Test
    public void testClearSms() {
        ClearMessagesResponse clearMessagesResponse = adbSms.clearMessages(null);
        assertNotNull(clearMessagesResponse);
        assertBaseResponse(clearMessagesResponse);
    }

    @Test
    public void testSendSms() {
        QueuedResponse queuedResponse = adbSms.sendMessage("3114836687", "This is a SMS sent from JUnit");
        assertNotNull(queuedResponse);
        assertTrue(queuedResponse.isQueued());
        assertBaseResponse(queuedResponse);
    }

    private void assertBaseResponse(BaseResponse response) {
        assertNotNull(response.getBrand());
        assertNotNull(response.getDevice());
        assertNotNull(response.getModel());
        assertNotNull(response.getRelease());
        assertNotNull(response.getSdk());
    }
}
