package com.codeslap.sms.core;

import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.telephony.SmsMessage;
import android.util.Log;

public class MessageStatusReceiver extends BroadcastReceiver {
    private static final String MESSAGE_STATUS_RECEIVED_ACTION =
            "com.codeslap.sms.core.MessageStatusReceiver.MESSAGE_STATUS_RECEIVED";
    private static final String[] ID_PROJECTION = new String[] { Telephony.Sms._ID };
    private static final String LOG_TAG = "MessageStatusReceiver";
    private static final Uri STATUS_URI = Uri.parse("content://sms/status");

    @Override
    public void onReceive(Context context, Intent intent) {
        //mContext = context;
        if (MESSAGE_STATUS_RECEIVED_ACTION.equals(intent.getAction())) {

            Uri messageUri = intent.getData();
            byte[] pdu = intent.getByteArrayExtra("pdu");

            updateMessageStatus(context, messageUri, pdu);
       }
    }

    private void updateMessageStatus(Context context, Uri messageUri, byte[] pdu) {
        // Create a "status/#" URL and use it to update the
        // message's status in the database.
        Cursor cursor = SqliteWrapper.query(context, context.getContentResolver(),
                messageUri, ID_PROJECTION, null, null, null);
        try {
            if (cursor.moveToFirst()) {
                int messageId = cursor.getInt(0);

                Uri updateUri = ContentUris.withAppendedId(STATUS_URI, messageId);
                SmsMessage message = SmsMessage.createFromPdu(pdu);
                int status = message.getStatus();
                ContentValues contentValues = new ContentValues(1);

                contentValues.put(Telephony.Sms.STATUS, status);
                SqliteWrapper.update(context, context.getContentResolver(),
                        updateUri, contentValues, null, null);
            } else {
                Log.e(LOG_TAG, "[MessageStatusReceiver] " + "Can't find message for status update: " + messageUri);
            }
        } finally {
            cursor.close();
        }
    }

}
