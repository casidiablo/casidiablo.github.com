package com.codeslap.sms.core;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.codeslap.persistence.Persistence;
import com.codeslap.sms.App;
import com.codeslap.sms.settings.GeneralSettings;

/**
 * @author cristian
 * @version 1.0
 */
public class WakeUpReceiver extends BroadcastReceiver {
    private static final String TAG = "adb:sms:wakeup";

    @Override
    public void onReceive(Context context, Intent intent) {
        GeneralSettings generalSettings = Persistence.quickPref(context, GeneralSettings.class);
        if (!generalSettings.isMaintainRunning()) {
            return;
        }
        if (((App) context.getApplicationContext()).isServiceRunning()) {
            return;
        }
        Log.d(TAG, "Waking app service after boot");
        AdbSmsService.start(context);
    }
}
