package com.codeslap.sms.core;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import com.codeslap.adb.sms.R;
import com.codeslap.persistence.Persistence;
import com.codeslap.sms.settings.GeneralSettings;

/**
 * @author cristian
 * @version 1.0
 */
public class NotificationHelper {
    private static final int STATE_NOTIFICATION = 8934;
    private static NotificationHelper sInstance;

    private final Context mContext;
    private final NotificationManager mNotificationManager;

    private NotificationHelper(Context context) {
        mContext = context;
        mNotificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
    }

    public static NotificationHelper getInstance(Context context) {
        if (sInstance == null) {
            sInstance = new NotificationHelper(context);
        }
        return sInstance;
    }

    public void showNotification(boolean running) {
        // create intent
        Intent notificationIntent = new Intent(mContext, NotificationReceiver.class);
        PendingIntent contentIntent = PendingIntent.getBroadcast(mContext, 0, notificationIntent, 0);

        // create notification
        Notification notification = new Notification(R.drawable.ic_stat_running, null, System.currentTimeMillis());
        String label;
        if (running) {
            label = mContext.getString(R.string.service_is_running);
        } else {
            label = mContext.getString(R.string.service_is_stopped);
            notification.icon = R.drawable.ic_stat_stopped;
        }

        GeneralSettings generalSettings = Persistence.quickPref(mContext, GeneralSettings.class);
        boolean toggle = generalSettings.isToggleServiceOnNotificationClick();
        String description;
        if (toggle) {
            if (running) {
                description = mContext.getString(R.string.click_to_stop_service);
            } else {
                description = mContext.getString(R.string.click_to_start_service);
            }
        } else {
            description = mContext.getString(R.string.click_to_launch_app);
        }
        notification.setLatestEventInfo(mContext, label, description, contentIntent);
        notification.flags |= Notification.FLAG_ONGOING_EVENT;

        // launch notification
        mNotificationManager.notify(STATE_NOTIFICATION, notification);
    }

    public void cancelNotification() {
        mNotificationManager.cancel(STATE_NOTIFICATION);
    }
}
