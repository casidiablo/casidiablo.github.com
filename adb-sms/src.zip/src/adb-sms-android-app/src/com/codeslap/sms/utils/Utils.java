package com.codeslap.sms.utils;

import android.util.Log;

import java.io.*;

/**
 * @author cristian
 * @version 1.0
 */
public class Utils {
    private static final String TAG = "adb:sms:utils";

    public static String toString(InputStream inputStream) throws IOException {
        String responseString;
        StringBuilder stringBuilder = new StringBuilder();
        BufferedReader r = new BufferedReader(new InputStreamReader(inputStream));
        String line;
        while ((line = r.readLine()) != null) {
            stringBuilder.append(line);
        }
        responseString = stringBuilder.toString();
        Utils.close(inputStream, r);
        return responseString;
    }

    private static void close(Closeable... closeables) {
        if (closeables == null) {
            return;
        }
        for (Closeable closeable : closeables) {
            try {
                closeable.close();
            } catch (Exception e) {
                Log.e(TAG, "Unable to close: " + closeable);
            }
        }
    }
}
