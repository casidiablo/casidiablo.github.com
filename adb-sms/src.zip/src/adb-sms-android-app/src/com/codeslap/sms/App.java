package com.codeslap.sms;

import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import com.codeslap.persistence.Persistence;
import com.codeslap.persistence.PersistenceConfig;
import com.codeslap.sms.core.AdbSmsActivity;
import com.codeslap.sms.core.AdbSmsService;
import com.codeslap.sms.core.NotificationHelper;
import com.codeslap.sms.settings.GeneralSettings;

/**
 * @author cristian
 * @version 1.0
 */
public class App extends Application {
    private AdbSmsActivity sMainActivity;

    @Override
    public void onCreate() {
        super.onCreate();
        PersistenceConfig.getPreference().match(GeneralSettings.class);
    }

    public boolean isServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (AdbSmsService.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public void notifyServiceStateChanged(boolean running) {
        GeneralSettings generalSettings = Persistence.quickPref(this, GeneralSettings.class);
        if (generalSettings.isShowNotification()) {
            NotificationHelper.getInstance(this).showNotification(running);
        } else {
            NotificationHelper.getInstance(this).cancelNotification();
        }
        if (sMainActivity == null) {
            return;
        }
        try {
            sMainActivity.serviceStateChanged(running);
        } catch (Exception ignored) {
        }
    }

    public void registerMainActivity(AdbSmsActivity activity) {
        sMainActivity = activity;
    }

    public void unregisterMainActivity() {
        sMainActivity = null;
    }
}
