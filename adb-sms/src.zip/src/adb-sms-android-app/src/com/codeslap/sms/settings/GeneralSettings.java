package com.codeslap.sms.settings;

import com.codeslap.persistence.pref.Preference;

/**
 * @author cristian
 * @version 1.0
 */
public class GeneralSettings {
    @Preference(value = "show_notification", defaultValue = "true")
    private boolean mShowNotification;
    @Preference(value = "toggle_service", defaultValue = "true")
    private boolean mToggleServiceOnNotificationClick;
    @Preference(value = "keep_running", defaultValue = "true")
    private boolean mMaintainRunning;
    @Preference(value = "server_port", defaultValue = "54546")
    private int mServerPort;

    public boolean isShowNotification() {
        return mShowNotification;
    }

    public void setShowNotification(boolean showNotification) {
        mShowNotification = showNotification;
    }

    public boolean isToggleServiceOnNotificationClick() {
        return mToggleServiceOnNotificationClick;
    }

    public void setToggleServiceOnNotificationClick(boolean toggleServiceOnNotificationClick) {
        mToggleServiceOnNotificationClick = toggleServiceOnNotificationClick;
    }

    public boolean isMaintainRunning() {
        return mMaintainRunning;
    }

    public void setMaintainRunning(boolean maintainRunning) {
        mMaintainRunning = maintainRunning;
    }

    public int getServerPort() {
        return mServerPort;
    }

    public void setServerPort(int serverPort) {
        mServerPort = serverPort;
    }
}
