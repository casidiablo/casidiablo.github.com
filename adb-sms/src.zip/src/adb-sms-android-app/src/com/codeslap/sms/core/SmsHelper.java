package com.codeslap.sms.core;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.BaseColumns;
import android.util.Log;
import com.codeslap.sms.common.bean.Conversation;
import com.codeslap.sms.common.bean.SmsMessage;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 * @author cristian
 * @version 1.0
 */
public class SmsHelper {

    private static final String TAG = "adb:sms:helper";
    private static final String BASE_CONVERSATIONS_URI = "content://mms-sms/conversations/";
    private static final String SMS_URI = "content://sms/";
    private static final Uri CONVERSATIONS_URI = Uri.parse(BASE_CONVERSATIONS_URI);
    private static final String[] DEFAULT_PROJECTION = new String[]{"*"};

    private static final String COLUMN_THREAD_ID = "thread_id";
    private static final String COLUMN_ID = BaseColumns._ID;
    private static final String COLUMN_MESSAGE_MIME_TYPE = "ct_t";
    private static final String MULTIPART_TYPE = "application/vnd.wap.multipart.related";

    private static SmsHelper sInstance;
    private final ContentResolver mContentResolver;
    private final Context mContext;

    private SmsHelper(Context context) {
        mContext = context;
        mContentResolver = context.getContentResolver();
    }

    public static SmsHelper getInstance(Context context) {
        if (sInstance == null) {
            sInstance = new SmsHelper(context);
        }
        return sInstance;
    }

    public List<Conversation> getAllSmsMessages() {
        Log.d(TAG, "Quering all sms messages...");
        Cursor query = null;
        ArrayList<Conversation> conversations;
        try {
            query = mContentResolver.query(CONVERSATIONS_URI, DEFAULT_PROJECTION, null, null, null);
            conversations = new ArrayList<Conversation>();
            if (query.moveToFirst()) {
                do {
                    long id = query.getLong(query.getColumnIndex(COLUMN_THREAD_ID));
                    List<SmsMessage> messagesInConversation = getMessagesInConversation(id);
                    if (!messagesInConversation.isEmpty()) {
                        Conversation conversation = new Conversation();
                        conversation.setId(id);
                        conversation.setMessages(messagesInConversation);
                        conversations.add(conversation);
                    }
                } while (query.moveToNext());
            }
        } finally {
            if (query != null) {
                query.close();
            }
        }
        return conversations;
    }

    public int clearSmsMessages(long since) {
        Log.d(TAG, "About to delete all messages since " + since);
        int deleted = mContentResolver.delete(CONVERSATIONS_URI, "date > ?", new String[]{String.valueOf(since)});
        Log.d(TAG, "Deleted " + deleted + " messages");
        return deleted;
    }

    public boolean sendMessage(String address, String body) {
        SmsMessageSender smsMessageSender = new SmsMessageSender(mContext, new String[]{address}, body, getOrCreateThreadId(address));
        try {
            smsMessageSender.sendMessage();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    private long getOrCreateThreadId(String address) {
        HashSet<String> recipients = new HashSet<String>();
        recipients.add(address);
        return Telephony.Threads.getOrCreateThreadId(mContext, recipients);
    }

    private List<SmsMessage> getMessagesInConversation(long id) {
        Uri uri = Uri.parse(BASE_CONVERSATIONS_URI + id);
        final String[] projection = new String[]{COLUMN_ID, COLUMN_MESSAGE_MIME_TYPE};
        List<SmsMessage> messages;
        Cursor query = null;
        try {
            query = mContentResolver.query(uri, projection, null, null, null);
            messages = new ArrayList<SmsMessage>();
            if (query.moveToFirst()) {
                do {
                    String string = query.getString(query.getColumnIndex("ct_t"));
                    if (MULTIPART_TYPE.equals(string)) {
                        // it's MMS
                    } else {
                        long smsId = query.getLong(query.getColumnIndex(BaseColumns._ID));
                        SmsMessage smsMessage = getSMSMessage(smsId);
                        if (smsMessage != null) {
                            messages.add(smsMessage);
                        }
                    }
                } while (query.moveToNext());
            }
        } finally {
            if (query != null) {
                query.close();
            }
        }
        return messages;
    }

    private SmsMessage getSMSMessage(long id) {
        Cursor cursor = null;
        try {
            cursor = mContentResolver.query(Uri.parse(SMS_URI + id), null, null, null, null);
            if (cursor.moveToFirst()) {
                SmsMessage smsMessage = new SmsMessage();
                smsMessage.setId(getLong(cursor, "_id"));
                smsMessage.setThreadId(getLong(cursor, "thread_id"));
                smsMessage.setAddress(getString(cursor, "address"));
                smsMessage.setPerson(getString(cursor, "person"));
                smsMessage.setDate(getLong(cursor, "date"));
                smsMessage.setDateSent(getLong(cursor, "date_sent"));
                smsMessage.setProtocol(getLong(cursor, "protocol"));
                smsMessage.setRead(getBoolean(cursor, "read"));
                smsMessage.setStatus(getInt(cursor, "status"));
                smsMessage.setType(getInt(cursor, "type"));
                smsMessage.setReplyPathPresent(getBoolean(cursor, "reply_path_present"));
                smsMessage.setSubject(getString(cursor, "subject"));
                smsMessage.setBody(getString(cursor, "body"));
                smsMessage.setServiceCenter(getString(cursor, "service_center"));
                smsMessage.setLocked(getBoolean(cursor, "locked"));
                smsMessage.setErrorCode(getInt(cursor, "error_code"));
                smsMessage.setSeen(getBoolean(cursor, "seen"));
                return smsMessage;
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return null;
    }

    private String getString(Cursor cursor, String column) {
        try {
            return cursor.getString(cursor.getColumnIndex(column));
        } catch (Exception e) {
            return null;
        }
    }

    private int getInt(Cursor cursor, String column) {
        try {
            return cursor.getInt(cursor.getColumnIndex(column));
        } catch (Exception e) {
            return 0;
        }
    }

    private long getLong(Cursor cursor, String column) {
        try {
            return cursor.getLong(cursor.getColumnIndex(column));
        } catch (Exception e) {
            return 0;
        }
    }

    private boolean getBoolean(Cursor cursor, String column) {
        return getInt(cursor, column) == 1;
    }
}
