package com.codeslap.sms.content;

import android.content.Context;
import android.content.res.AssetManager;
import com.codeslap.adb.sms.R;
import com.codeslap.sms.common.bean.*;
import com.codeslap.sms.utils.Utils;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author cristian
 * @version 1.0
 */
public class HtmlGenerator implements ContentGenerator {

    // used to format since date in clear messages method
    private static final SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy-MM-dd");
    private static final SimpleDateFormat FORMATTER_TIME = new SimpleDateFormat("yyyy-MM-dd hh:mm a");

    // template variables
    private static final String TITLE = "_title_";
    private static final String CONTENT = "_content_";

    // html tags
    private static final String TD_START = "<td>";
    private static final String TD_END = "</td>\n";
    private static final String TR_START = "<tr>";
    private static final String TR_END = "</tr>\n";
    private static final String TH_START = "<th colspan='2'>";
    private static final String TH_END = "</th>";
    private static final String TABLE_START = "<table style='margin-left: 30px;margin-right: 30px;'>\n";
    private static final String TABLE_END = "</table>";
    private static final String P_START = "<p>";
    private static final String P_END = "</p>";
    private static final String A_START = "<a href='/%s'>";
    private static final String A_END = "</a>";

    // generator fields
    private final String mTemplate;
    private final Context mContext;

    public HtmlGenerator(Context context) {
        mContext = context;
        AssetManager assets = context.getAssets();
        try {
            InputStream inputStream = assets.open("template.htm");
            mTemplate = Utils.toString(inputStream);
        } catch (IOException e) {
            throw new RuntimeException("Could not initiate template.htm");
        }
    }

    @Override
    public String getContentType() {
        return "text/html";
    }

    @Override
    public String getAllMessagesContent(GetAllMessagesResponse getAllMessagesResponse) {
        StringBuilder content = new StringBuilder(TABLE_START);
        for (Conversation conversation : getAllMessagesResponse.getConversations()) {
            content.append(TR_START)
                    .append(TH_START)
                    .append(mContext.getString(R.string.conversation_id, conversation.getId()))
                    .append(TH_END)
                    .append(TR_END);
            for (SmsMessage smsMessage : conversation.getMessages()) {
                content.append(TR_START);
                content.append(TD_START).append(smsMessage.getAddress()).append(TD_END);
                content.append(TD_START).append(smsMessage.getBody()).append(TD_END);
                content.append(TD_START).append(FORMATTER_TIME.format(new Date(smsMessage.getDate()))).append(TD_END);
                content.append(TR_END);
            }
        }
        content.append(TABLE_END);
        return applyTemplate(getString(R.string.list_of_messages), content.toString());
    }

    @Override
    public String getClearMessagesContent(ClearMessagesResponse clearMessagesResponse) {
        // add the number of deleted messages
        StringBuilder body = new StringBuilder(P_START);
        body.append(mContext.getString(R.string.deleted, clearMessagesResponse.getDeleted()));
        body.append(P_END);

        // add since deletion label
        String dateSince = FORMATTER.format(new Date(clearMessagesResponse.getSince()));
        String deletedSince = mContext.getString(R.string.messages_were_deleted_since, dateSince);
        body.append(P_START).append(deletedSince).append(P_END);

        return applyTemplate(getString(R.string.messages_deletion), body.toString());
    }

    @Override
    public String getSendMessageContent(QueuedResponse queuedResponse) {
        String message = P_START;
        if (queuedResponse.isQueued()) {
            message += getString(R.string.message_queued_successfully);
        } else {
            message += getString(R.string.message_was_not_queued);
        }
        message += P_END + P_START + String.format(A_START, "sender.htm") + getString(R.string.go_back) + A_END + P_END;
        return applyTemplate(getString(R.string.message_sender), message);
    }

    private String getString(int resId) {
        return mContext.getString(resId);
    }

    private String applyTemplate(String title, String contents) {
        return String.format(mTemplate, title, title, contents);
    }
}
