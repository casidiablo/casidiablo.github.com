package com.codeslap.sms.core;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import com.codeslap.adb.sms.R;
import com.codeslap.sms.common.bean.*;
import com.codeslap.sms.content.ContentGenerator;
import com.codeslap.sms.content.HtmlGenerator;
import com.codeslap.sms.content.XmlGenerator;
import com.codeslap.sms.utils.Utils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Locale;

import static com.codeslap.sms.common.HttpConstants.*;

/**
 * @author cristian
 * @version 1.0
 */
class AdbHttpHandler extends AbstractHandler {
    private static final String TAG = "adb:sms";

    private final ContentGenerator mHtmlGenerator;
    private static final ContentGenerator XML_GENERATOR = new XmlGenerator();

    private static final int HTML_TYPE = 0;
    private static final int XML_TYPE = 1;
    private static final DateTimeFormatter SINCE_FORMATTER = DateTimeFormat.forPattern("yyyy-MM-dd");

    static {
        SINCE_FORMATTER.withLocale(Locale.getDefault());
    }

    private final Context mContext;
    private final AssetManager mAssetManager;

    public AdbHttpHandler(Context context) {
        mContext = context;
        mAssetManager = mContext.getAssets();
        mHtmlGenerator = new HtmlGenerator(context);
    }

    @Override
    public void handle(String target, HttpServletRequest request, HttpServletResponse response, int dispatch) throws IOException, ServletException {
        try {
            String responseString = "<h1>ADB SMS - 404</h1>";

            // get the type of the response
            int type = getResponseType(target);
            ContentGenerator generator;
            switch (type) {
                case XML_TYPE:
                    generator = XML_GENERATOR;
                    break;
                default:
                    generator = mHtmlGenerator;
            }

            // set the content type
            response.setContentType(generator.getContentType());

            // try to handle the request
            SmsHelper smsHelper = SmsHelper.getInstance(mContext);
            boolean binary = false;
            if (target.startsWith(GET_ALL_MESSAGES)) {
                List<Conversation> allSmsMessages = smsHelper.getAllSmsMessages();
                GetAllMessagesResponse getAllMessagesResponse = new GetAllMessagesResponse();
                getAllMessagesResponse.setConversations(allSmsMessages);
                populateBaseResponse(getAllMessagesResponse);

                responseString = generator.getAllMessagesContent(getAllMessagesResponse);
            } else if (target.startsWith(CLEAR_MESSAGES)) {
                long since = calculateSinceParameter(request);
                int deleted = smsHelper.clearSmsMessages(since);

                // create response object and parse it
                ClearMessagesResponse clearMessagesResponse = new ClearMessagesResponse();
                clearMessagesResponse.setDeleted(deleted);
                clearMessagesResponse.setSince(since);
                populateBaseResponse(clearMessagesResponse);

                responseString = generator.getClearMessagesContent(clearMessagesResponse);
            } else if (target.startsWith(SEND_MESSAGE)) {
                if (!request.getMethod().equalsIgnoreCase("post")) {
                    response.setContentType(mHtmlGenerator.getContentType());
                    responseString = mContext.getString(R.string.must_be_called_using_post_request, target);
                } else {
                    String address = request.getParameter(PARAM_NUMBER);
                    String body = request.getParameter(PARAM_BODY);

                    boolean messageQueued = smsHelper.sendMessage(address, body);
                    QueuedResponse queuedResponse = new QueuedResponse();
                    queuedResponse.setQueued(messageQueued);
                    populateBaseResponse(queuedResponse);

                    responseString = generator.getSendMessageContent(queuedResponse);
                }
            } else {
                if (target.equals("/")) {
                    target = "index.htm";
                } else {
                    target = target.replaceFirst("/", "");
                }

                if (target.endsWith(CSS_EXTENSION)) {
                    response.setContentType(CSS_MIME_TYPE);
                } else if (target.endsWith(PNG_EXTENSION)) {
                    binary = true;
                    response.setContentType(PNG_MIME_TYPE);
                } else if (target.endsWith(JPG_EXTENSION)) {
                    binary = true;
                    response.setContentType(JPG_MIME_TYPE);
                } else if (target.endsWith(ICO_EXTENSION)) {
                    binary = true;
                    response.setContentType(ICON_MIME_TYPE);
                }

                InputStream inputStream;
                try {
                    inputStream = mAssetManager.open(target);
                } catch (IOException e) {
                    Log.d(TAG, "Error handling " + target, e);
                    return;
                }

                if (binary) {
                    byte[] buffer = new byte[1024];
                    while (inputStream.read(buffer) > 0) {
                        response.getOutputStream().write(buffer);
                    }
                } else {
                    responseString = Utils.toString(inputStream);
                }
            }

            //send response back
            response.setStatus(HttpServletResponse.SC_OK);
            if (!binary) {
                response.getWriter().println(responseString);
            }
            ((Request) request).setHandled(true);
        } catch (Exception ex) {
            Log.e(TAG, ex.getMessage(), ex);
        }
    }

    private long calculateSinceParameter(HttpServletRequest request) {
        DateTime now = DateTime.now();
        String sinceParameter = request.getParameter(PARAM_SINCE);
        if (VALUE_TODAY.equals(sinceParameter)) {
            return now.withTime(0, 0, 0, 1).getMillis();
        } else if (VALUE_YESTERDAY.equals(sinceParameter)) {
            return now.minusDays(1).withTime(0, 0, 0, 1).getMillis();
        } else if (VALUE_THIS_WEEK.equals(sinceParameter)) {
            return now.withDayOfWeek(DateTimeConstants.MONDAY).withTime(0, 0, 0, 1).getMillis();
        } else if (VALUE_LAST_WEEK.equals(sinceParameter)) {
            return now.withDayOfWeek(DateTimeConstants.MONDAY).minusWeeks(1).withTime(0, 0, 0, 1).getMillis();
        }
        try {
            return SINCE_FORMATTER.parseDateTime(sinceParameter).withTime(0, 0, 0, 1).getMillis();
        } catch (Exception ignored) {
        }
        try {
            return Long.parseLong(sinceParameter);
        } catch (Exception ignored) {
        }
        return 0;
    }

    private void populateBaseResponse(BaseResponse baseResponse) {
        baseResponse.setBrand(Build.BRAND);
        baseResponse.setDevice(Build.DEVICE);
        baseResponse.setModel(Build.MODEL);
        baseResponse.setRelease(Build.VERSION.RELEASE);
        baseResponse.setSdk(Build.VERSION.SDK_INT);
    }

    private int getResponseType(String target) {
        if (TextUtils.isEmpty(target)) {
            return HTML_TYPE;
        }
        return target.endsWith(XML_EXTENSION) ? XML_TYPE : HTML_TYPE;
    }
}
