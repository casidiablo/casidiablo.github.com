package com.codeslap.sms.content;

import com.codeslap.sms.common.bean.ClearMessagesResponse;
import com.codeslap.sms.common.bean.GetAllMessagesResponse;
import com.codeslap.sms.common.bean.QueuedResponse;

/**
 * @author cristian
 * @version 1.0
 */
public interface ContentGenerator {
    String getContentType();

    String getAllMessagesContent(GetAllMessagesResponse getAllMessagesResponse);

    String getClearMessagesContent(ClearMessagesResponse clearMessagesResponse);

    String getSendMessageContent(QueuedResponse queuedResponse);
}
