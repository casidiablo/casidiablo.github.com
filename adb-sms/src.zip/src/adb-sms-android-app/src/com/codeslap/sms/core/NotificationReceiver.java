package com.codeslap.sms.core;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.codeslap.persistence.Persistence;
import com.codeslap.sms.App;
import com.codeslap.sms.settings.GeneralSettings;

/**
 * @author cristian
 * @version 1.0
 */
public class NotificationReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        GeneralSettings generalSettings = Persistence.quickPref(context, GeneralSettings.class);
        boolean toggle = generalSettings.isToggleServiceOnNotificationClick();
        if (toggle) {
            if (((App) context.getApplicationContext()).isServiceRunning()) {
                AdbSmsService.stop(context);
            } else {
                AdbSmsService.start(context);
            }
        } else {
            Intent mainIntent = new Intent(context, AdbSmsActivity.class);
            mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(mainIntent);
        }
    }
}
