package com.codeslap.sms.core;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;
import com.codeslap.adb.sms.R;
import com.codeslap.persistence.Persistence;
import com.codeslap.persistence.PreferencesAdapter;
import com.codeslap.sms.App;
import com.codeslap.sms.settings.GeneralSettings;

/**
 * @author cristian
 * @version 1.0
 */
public class AdbSmsActivity extends Activity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {

    private static final String PORT_REPLACEMENT = "\\$port\\$";
    private TextView mCurrentState;
    private Button mToggleState;
    private ImageView mStateDrawable;
    private CheckBox mNotificationAction;
    private static final int SERVER_PORT_DIALOG = 67472;
    private TextView mServerPortLbl;
    private TextView mAdbHelpLbl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        GeneralSettings generalSettings = Persistence.quickPref(this, GeneralSettings.class);

        mCurrentState = (TextView) findViewById(R.id.current_state);
        mToggleState = (Button) findViewById(R.id.toggle_state);
        mStateDrawable = (ImageView) findViewById(R.id.state_drawable);

        CheckBox showNotification = (CheckBox) findViewById(R.id.show_notification);
        boolean shouldShowNotification = generalSettings.isShowNotification();
        showNotification.setChecked(shouldShowNotification);
        showNotification.setOnCheckedChangeListener(this);

        boolean serviceRunning = isServiceRunning();
        if (shouldShowNotification) {
            NotificationHelper.getInstance(this).showNotification(serviceRunning);
        }

        mNotificationAction = (CheckBox) findViewById(R.id.notification_action);
        mNotificationAction.setChecked(generalSettings.isToggleServiceOnNotificationClick());
        mNotificationAction.setOnCheckedChangeListener(this);

        CheckBox keepRunning = (CheckBox) findViewById(R.id.maintain_service_running);
        keepRunning.setOnCheckedChangeListener(this);
        keepRunning.setChecked(generalSettings.isMaintainRunning());

        mServerPortLbl = (TextView) findViewById(R.id.server_port);
        mAdbHelpLbl = (TextView) findViewById(R.id.adb_help);
        mAdbHelpLbl.setMovementMethod(LinkMovementMethod.getInstance());
        String format = getString(R.string.extended_help);
        mAdbHelpLbl.setText(Html.fromHtml(format.replaceAll(PORT_REPLACEMENT, String.valueOf(generalSettings.getServerPort()))));

        mServerPortLbl.setText(getString(R.string.server_port, generalSettings.getServerPort()));

        mServerPortLbl.setOnClickListener(this);
        mToggleState.setOnClickListener(this);

        updateLabels(serviceRunning);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ((App) getApplicationContext()).registerMainActivity(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        ((App) getApplicationContext()).unregisterMainActivity();
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        PreferencesAdapter preferenceAdapter = Persistence.getPreferenceAdapter(this);
        GeneralSettings generalSettings = preferenceAdapter.retrieve(GeneralSettings.class);
        NotificationHelper notificationHelper = NotificationHelper.getInstance(this);
        switch (buttonView.getId()) {
            case R.id.show_notification:
                if (isChecked) {
                    notificationHelper.showNotification(isServiceRunning());
                } else {
                    notificationHelper.cancelNotification();
                }
                mNotificationAction.setEnabled(isChecked);
                generalSettings.setShowNotification(isChecked);
                preferenceAdapter.store(generalSettings);
                break;
            case R.id.notification_action:
                generalSettings.setToggleServiceOnNotificationClick(isChecked);
                preferenceAdapter.store(generalSettings);
                notificationHelper.showNotification(isServiceRunning());
                break;
            case R.id.maintain_service_running:
                generalSettings.setMaintainRunning(isChecked);
                preferenceAdapter.store(generalSettings);
                if (isChecked && !isServiceRunning()) {
                    AdbSmsService.start(this);
                }
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.toggle_state:
                if (!isServiceRunning()) {
                    AdbSmsService.start(this);
                } else {
                    AdbSmsService.stop(this);
                }
                break;
            case R.id.server_port:
            case R.id.adb_help:
                showDialog(SERVER_PORT_DIALOG);
                break;
        }
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        if (id == SERVER_PORT_DIALOG) {
            // get the settings
            GeneralSettings generalSettings = Persistence.quickPref(this, GeneralSettings.class);

            // inflate the dialog view
            LayoutInflater inflater = LayoutInflater.from(this);
            View root = inflater.inflate(R.layout.server_port, null);

            // set the current port to the edit text
            final EditText serverPortInput = (EditText) root.findViewById(R.id.server_port_input);
            serverPortInput.setText(String.valueOf(generalSettings.getServerPort()));

            // create and return the alert dialog
            return new AlertDialog.Builder(this)
                    .setTitle(R.string.change_listening_port)
                    .setView(root)
                    .setPositiveButton(R.string.save, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            String portEntered = serverPortInput.getText().toString();
                            handleEnteredPort(portEntered);
                        }
                    })
                    .setNegativeButton(R.string.cancel, null)
                    .create();
        }
        return super.onCreateDialog(id);
    }

    private void handleEnteredPort(String portEntered) {
        if (portEntered == null || TextUtils.isEmpty(portEntered.trim())) {
            Toast.makeText(this, R.string.entered_port_invalid, Toast.LENGTH_LONG).show();
        } else {
            try {
                saveNewPortPreference(Integer.parseInt(portEntered.trim()));
            } catch (Exception e) {
                Toast.makeText(this, R.string.error_parsing_entered_port, Toast.LENGTH_LONG).show();
            }
        }
    }

    private void saveNewPortPreference(int newPort) {
        // persist new value to shared preferences
        PreferencesAdapter preferenceAdapter = Persistence.getPreferenceAdapter(this);
        GeneralSettings generalSettings = preferenceAdapter.retrieve(GeneralSettings.class);
        generalSettings.setServerPort(newPort);
        preferenceAdapter.store(generalSettings);

        // restart the service
        AdbSmsService.restart(this);
    }

    public void serviceStateChanged(boolean running) {
        updateLabels(running);
        // get preferences
        PreferencesAdapter preferenceAdapter = Persistence.getPreferenceAdapter(this);
        GeneralSettings generalSettings = preferenceAdapter.retrieve(GeneralSettings.class);
        // change current port labels
        mServerPortLbl.setText(getString(R.string.server_port, generalSettings.getServerPort()));
        String format = getString(R.string.extended_help);
        mAdbHelpLbl.setText(Html.fromHtml(format.replaceAll(PORT_REPLACEMENT, String.valueOf(generalSettings.getServerPort()))));
    }

    private boolean isServiceRunning() {
        return ((App) getApplicationContext()).isServiceRunning();
    }

    private void updateLabels(boolean serviceRunning) {
        if (serviceRunning) {
            mCurrentState.setText(R.string.service_is_running);
            mToggleState.setText(R.string.stop_service);
            mStateDrawable.setBackgroundResource(R.drawable.running_bg);
        } else {
            mCurrentState.setText(R.string.service_is_stopped);
            mToggleState.setText(R.string.start_service);
            mStateDrawable.setBackgroundResource(R.drawable.stopped_bg);
        }
    }
}
