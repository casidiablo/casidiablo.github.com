package com.codeslap.sms.core;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;
import com.codeslap.adb.sms.R;
import com.codeslap.persistence.Persistence;
import com.codeslap.sms.App;
import com.codeslap.sms.settings.GeneralSettings;
import org.mortbay.jetty.Server;

/**
 * @author cristian
 * @version 1.0
 */
public class AdbSmsService extends Service {

    private Server mServer;
    private static final String ACTION_START = "com.codeslap.sms.ACTION_START_JETTY_SERVICE";
    private static final String ACTION_RESTART = "com.codeslap.sms.ACTION_RESTART_JETTY_SERVICE";
    private static final String TAG = "adb:sms:service";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            if (mServer == null) {
                startJettyService();
            }
            return Service.START_STICKY;
        }
        if (intent.getAction() != null) {
            if (ACTION_START.equals(intent.getAction())) {
                startJettyService();
            } else if(ACTION_RESTART.equals(intent.getAction())) {
                stopJettyService();
                startJettyService();
            }
        }
        return Service.START_STICKY;
    }

    private void startJettyService() {
        GeneralSettings generalSettings = Persistence.quickPref(this, GeneralSettings.class);
        int serverPort = generalSettings.getServerPort();
        mServer = new Server(serverPort);
        mServer.setHandler(new AdbHttpHandler(this));
        try {
            mServer.start();
            ((App) getApplicationContext()).notifyServiceStateChanged(true);
        } catch (Exception e) {
            String message = getString(R.string.could_not_start_server, e.getMessage());
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            Log.e(TAG, message, e);
        }
    }

    private void stopJettyService() {
        if (mServer == null) {
            return;
        }
        try {
            mServer.stop();
            ((App) getApplicationContext()).notifyServiceStateChanged(false);
        } catch (Exception e) {
            Log.e(TAG, "Could not stop Jetty server", e);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            mServer.stop();
            ((App) getApplicationContext()).notifyServiceStateChanged(false);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void start(Context context) {
        Intent service = new Intent(context, AdbSmsService.class);
        service.setAction(ACTION_START);
        context.startService(service);
    }

    public static void stop(Context context) {
        context.stopService(new Intent(context, AdbSmsService.class));
    }

    public static void restart(Context context) {
        Intent service = new Intent(context, AdbSmsService.class);
        service.setAction(ACTION_RESTART);
        context.startService(service);
    }
}
