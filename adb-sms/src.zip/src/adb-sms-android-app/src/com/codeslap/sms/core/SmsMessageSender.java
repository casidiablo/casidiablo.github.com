package com.codeslap.sms.core;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.telephony.SmsManager;

import java.util.ArrayList;

class SmsMessageSender {
    private final Context mContext;
    private final int mNumberOfDests;
    private final String[] mDests;
    private final String mMessageText;
    private final String mServiceCenter;
    private final long mThreadId;
    private final long mTimestamp;

    private static final String[] SERVICE_CENTER_PROJECTION = new String[]{
            Telephony.Sms.Conversations.REPLY_PATH_PRESENT,
            Telephony.Sms.Conversations.SERVICE_CENTER,
    };

    private static final int COLUMN_REPLY_PATH_PRESENT = 0;
    private static final int COLUMN_SERVICE_CENTER = 1;

    public SmsMessageSender(Context context, String[] dests, String msgText, long threadId) {
        mContext = context;
        mMessageText = msgText;
        mNumberOfDests = dests.length;
        mDests = new String[mNumberOfDests];
        System.arraycopy(dests, 0, mDests, 0, mNumberOfDests);
        mTimestamp = System.currentTimeMillis();
        mThreadId = threadId;
        mServiceCenter = getOutgoingServiceCenter(mThreadId);
    }

    public void sendMessage() {
        if ((mMessageText == null) || (mNumberOfDests == 0)) {
            // Don't try to send an empty message.
            throw new RuntimeException("Null message body or dest.");
        }

        SmsManager smsManager = SmsManager.getDefault();

        for (int i = 0; i < mNumberOfDests; i++) {
            ArrayList<String> messages = smsManager.divideMessage(mMessageText);
            int messageCount = messages.size();

            if (messageCount == 0) {
                // Don't try to send an empty message.
                throw new RuntimeException("SmsMessageSender.sendMessage: divideMessage returned " +
                        "empty messages. Original message is \"" + mMessageText + "\"");
            }

            ArrayList<PendingIntent> deliveryIntents = new ArrayList<PendingIntent>(messageCount);
            ArrayList<PendingIntent> sentIntents = new ArrayList<PendingIntent>(messageCount);
            Uri uri = null;
            try {
                uri = Telephony.Sms.Outbox.addMessage(mContext.getContentResolver(), mDests[i],
                        mMessageText, null, mTimestamp, false, mThreadId);
            } catch (SQLiteException e) {
                SqliteWrapper.checkSQLiteException(mContext, e);
            }

            //noinspection ForLoopReplaceableByForEach
            for (int j = 0; j < messageCount; j++) {
                sentIntents.add(PendingIntent.getBroadcast(
                        mContext, 0,
                        new Intent(SmsReceiverService.MESSAGE_SENT_ACTION,
                                uri,
                                mContext,
                                SmsReceiver.class),
                        0));
            }

            try {
                smsManager.sendMultipartTextMessage(
                        mDests[i], mServiceCenter, messages, sentIntents,
                        deliveryIntents);
            } catch (Exception ex) {
                throw new RuntimeException("SmsMessageSender.sendMessage: caught " + ex +
                        " from SmsManager.sendMultipartTextMessage()");
            }
        }
    }

    /**
     * Get the service center to use for a reply.
     * <p/>
     * The rule from TS 23.040 D.6 is that we send reply messages to
     * the service center of the message to which we're replying, but
     * only if we haven't already replied to that message and only if
     * <code>TP-Reply-Path</code> was set in that message.
     * <p/>
     * Therefore, return the service center from the most recent
     * message in the conversation, but only if it is a message from
     * the other party, and only if <code>TP-Reply-Path</code> is set.
     * Otherwise, return null.
     */
    private String getOutgoingServiceCenter(long threadId) {
        Cursor cursor = null;

        try {
            cursor = SqliteWrapper.query(mContext, mContext.getContentResolver(),
                    Telephony.Sms.CONTENT_URI, SERVICE_CENTER_PROJECTION,
                    "thread_id = " + threadId, null, "date DESC");

            if ((cursor == null) || !cursor.moveToFirst()) {
                return null;
            }

            boolean replyPathPresent = (1 == cursor.getInt(COLUMN_REPLY_PATH_PRESENT));
            return replyPathPresent ? cursor.getString(COLUMN_SERVICE_CENTER) : null;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }
}
