package com.codeslap.sms.content;

import com.codeslap.sms.common.HttpConstants;
import com.codeslap.sms.common.bean.ClearMessagesResponse;
import com.codeslap.sms.common.bean.GetAllMessagesResponse;
import com.codeslap.sms.common.bean.QueuedResponse;
import com.codeslap.sms.common.xml.XmlHelper;

/**
 * @author cristian
 * @version 1.0
 */
public class XmlGenerator implements ContentGenerator {

    @Override
    public String getContentType() {
        return HttpConstants.XML_MIME_TYPE;
    }

    @Override
    public String getAllMessagesContent(GetAllMessagesResponse getAllMessagesResponse) {
        return XmlHelper.toXml(getAllMessagesResponse);
    }

    @Override
    public String getClearMessagesContent(ClearMessagesResponse clearMessagesResponse) {
        return XmlHelper.toXml(clearMessagesResponse);
    }

    @Override
    public String getSendMessageContent(QueuedResponse queuedResponse) {
        return XmlHelper.toXml(queuedResponse);
    }
}
